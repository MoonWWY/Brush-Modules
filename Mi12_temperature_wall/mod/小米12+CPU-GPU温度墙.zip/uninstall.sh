rm -rf /data/media/0/Android/Mi12_temperature_wall/
rm -rf /data/adb/modules/Mi12_temperature_wall/