#!/system/bin/sh
rm -rf /data/adb/modules/barrier_free_litiaotiao