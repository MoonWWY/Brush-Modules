#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
/system/bin/sh $ModuleAdd/Initialization.sh
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl

KillLog_time=`date +"%H:%M:%S"`
Mod_information=/data/adb/modules/Mi12_TemperatureControl/module.prop
Install_time=`cat ${Config_add}/Install_time`
NowTime_Ymd=`date +"%Y%m%d"`
NowTime_H=`date +"%H"`
Time_Ymd=`cat ${Config_add}/Time_Ymd`
Time_H=`cat ${Config_add}/Time_H`
Time_Day=`expr $NowTime_Ymd - $Time_Ymd`
if [ "$NowTime_H" -ge "$Time_H" ]; then
  Time_Hr=`expr $NowTime_H - $Time_H`
else
  Time_Hr=`expr $Time_H - $NowTime_H`
fi

function Update_information1(){
sed -i "/^description=/c description=当前模式：[ ✈️极速游戏 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充，淦掉云控，游戏全性能。安装日期：[ $Install_time ] | 使用时长：[ ${Time_Day}天 ${Time_Hr}小时 ]" "$Mod_information"
}

function Update_information2(){
sed -i "/^description=/c description=当前模式：[ 🛰️淦掉云控 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充，淦掉云控。安装日期：[ $Install_time ] | 使用时长：[ ${Time_Day}天 ${Time_Hr}小时 ]" "$Mod_information"
}

function Update_information3(){
sed -i "/^description=/c description=当前模式：[ 💀淦掉温控 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充。安装日期：[ $Install_time ] | 使用时长：[ ${Time_Day}天 ${Time_Hr}小时 ]" "$Mod_information"
}

if [ ! -f "$Config_add/配置文件.conf" ];then
  cp -rf ${ModuleAdd}/配置文件.conf ${Config_add}/
fi
cp -rf ${Config_add}/配置文件.conf ${ModuleAdd}/
if [ -f "$ModuleAdd/配置文件.conf" ]; then
  Current_mode=`cat ${ModuleAdd}/配置文件.conf | grep "Current_mode" | cut -d"=" -f2`
  if [ "$Current_mode" = "killcloud" ]; then
    /system/bin/sh ${ModuleAdd}/Killcloud.sh
    Update_information2
  elif [ "$Current_mode" = "game" ]; then
    /system/bin/sh ${ModuleAdd}/Killcloud.sh
    /system/bin/sh ${ModuleAdd}/Game.sh
    Update_information1
  else
    /system/bin/sh ${ModuleAdd}/Initialization.sh
    Update_information3
  fi
else
  /system/bin/sh ${ModuleAdd}/Initialization.sh
  Update_information3
fi