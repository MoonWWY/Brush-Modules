#!/system/bin/sh
MODDIR=${0%/*}
chmod -R 777 $MODDIR/root
chmod 777 $MODDIR/*.sh
Install_time=`cat $MODDIR/Install_time`
sed -i "/^description=/c description=当前模式：[ -📱⏰60s- ] 安装日期：[ $Install_time ] | 使用时长：[ -🖥️计算中- ]" $MODDIR/module.prop
sleep 1m
crond -c $MODDIR/root
/system/bin/sh $MODDIR/I_Control.sh