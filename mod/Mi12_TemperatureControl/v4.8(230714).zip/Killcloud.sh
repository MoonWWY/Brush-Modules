#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl

thermal_files="thermal-4k.conf
thermal-8k.conf
thermal-abnormal.conf
thermal-arvr.conf
thermal-camera.conf
thermal-chg-only.conf
thermal-class0.conf
thermal-engine.conf
thermal-hp-mgame.conf
thermal-hp-normal.conf
thermal-huanji.conf
thermal-iec-4k.conf
thermal-iec-abnormal.conf
thermal-iec-camera.conf
thermal-iec-class0.conf
thermal-iec-huanji.conf
thermal-iec-mgame.conf
thermal-iec-navigation.conf
thermal-iec-nolimits.conf
thermal-iec-normal.conf
thermal-iec-per-class0.conf
thermal-iec-per-navigation.conf
thermal-iec-per-normal.conf
thermal-iec-per-video.conf
thermal-iec-phone.conf
thermal-iec-tgame.conf
thermal-iec-video.conf
thermal-iec-videochat.conf
thermal-k1a-phone.conf
thermal-map.conf
thermal-mgame.conf
thermal-navigation.conf
thermal-nolimits.conf
thermal-normal.conf
thermal-per-camera.conf
thermal-per-class0.conf
thermal-per-huanji.conf
thermal-per-navigation.conf
thermal-per-normal.conf
thermal-per-video.conf
thermal-phone.conf
thermal-region-map.conf
thermal-tgame.conf
thermal-video.conf
thermal-videochat.conf
thermald-devices.conf"

function Killcloud(){
mkdir -p $ModuleAdd/thermal
for files in $thermal_files; do
  touch $ModuleAdd/thermal/$files
done

Cloud_thermals=`ls /data/vendor/thermal/config`
Cloud_jump_thermals="/mi_thermald/"

for Cloud_thermal in $Cloud_thermals; do
  echo $Cloud_jump_thermals | grep "$Cloud_thermal" && {
    cp -rf /data/vendor/thermal/config/$Cloud_thermal $ModuleAdd/thermal/
  } || {
    if [ ! -f "$ModuleAdd/thermal/$Cloud_thermal" ]; then
      touch $ModuleAdd/thermal/$Cloud_thermal
    fi
  }
done

chattr -R -i /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
cp -rf $ModuleAdd/thermal/* /data/vendor/thermal/config/
chmod 644 /data/vendor/thermal/config/*
chmod 644 /data/vendor/thermal/config
chattr -R +i /data/vendor/thermal/config
}
Killcloud