#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl

function Killcloud(){
chattr -R -i /data/vendor/thermal/config
cp -rf $ModuleAdd/clouds/* /data/vendor/thermal/config/
chmod -R 644 /data/vendor/thermal/config/
chattr -R +i /data/vendor/thermal/config
}
Killcloud