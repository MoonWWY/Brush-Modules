#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
DUBUG_FLAG=true
SKIPUNZIP=0
ASH_STANDALONE=0

function Information() {
name="`grep_prop name $TMPDIR/module.prop`"
version="`grep_prop version $TMPDIR/module.prop`"
author="`grep_prop author $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
ui_print "********************"
ui_print "- 模块信息"
ui_print "- 名称: $name"
ui_print "- 版本: $version"
ui_print "- 作者：$author"
ui_print "- $description"
ui_print "********************"
}

function Ifff() {
ui_print "————————————————————————————————————"
ui_print "- 本模块运行模式："
ui_print "- 模式1：常规模式“default”：日常使用性能释放"
ui_print "- 模式2：淦掉云控“killcloud”：一些场景不受温控限制"
ui_print "- 模式3：极速游戏“game”:彻底摆脱大部分温控限制，游戏不掉帧"
ui_print "————————————————————————————————————"
ui_print "  安装默认模式为：模式3"
ui_print "  如需更换，请在“/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf”中修改"
ui_print "————————————————————————————————————"
sleep 2
ui_print "- 准备安装模块~"
}

function Install() {
sleep 1
ui_print "- Install~"

ui_print "- 🚙备份温控文件"
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
First_install_bak=${Config_add}/First_install_bak
Jump_thermals="/system/vendor/bin/mi_thermald
/system/vendor/etc/thermal-engine.conf
/system/vendor/etc/thermal-normal.conf
/system/vendor/etc/thermal-map.conf
/system/vendor/bin/thermal-engine
/system/bin/thermalserviced"
Cloud_thermals=`ls /data/vendor/thermal/config`
if [ ! -d "$First_install_bak" ]; then
  mkdir -p ${First_install_bak}/cloud_thermals
  mkdir -p ${First_install_bak}/Jump_thermals
  for Cloud_thermal in $Cloud_thermals; do
    cp -rf /data/vendor/thermal/config/$Cloud_thermal ${First_install_bak}/cloud_thermals
  done
  for Jump_thermal in $Jump_thermals; do
    if [ -s "$Jump_thermal" ]; then
      cp -rf $Jump_thermal $First_install_bak/Jump_thermals
    fi
  done
fi

ui_print "- 💞初始化模块文件"
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}
install_magisk_busybox
mkdir -p $MODPATH/root
echo "#每20分钟执行一次I_Control.sh，淦云控
*/20 * * * * sh /data/adb/modules/Mi12_TemperatureControl/I_Control.sh">$MODPATH/root/root
echo "#!/system/bin/sh
/system/bin/sh /data/adb/modules/Mi12_TemperatureControl/I_Control.sh >/dev/null 2>&1 &
echo "- 配置生效成功！"">$Config_add/一键生效配置.sh
product=$MODPATH/system/product
if [ ! -d "$product" ]; then
  mkdir -p ${product}
  cp -p -a -R /system/product/pangu/system/* ${product}
fi
sed -i "/^description=/c description=当前模式：[ NULL | -等待重启- ] ，Mi·淦掉温控：不跳电淦温控，淦掉云控，满血快充(会阶梯式充电，也会受机身48℃温度墙影响)，游戏不掉帧，兼容A12/A13，MIUI13/MIUI14。" $MODPATH/module.prop

ui_print "- ✍🏻️初始化云控"
/system/bin/sh $MODPATH/Initialization.sh >/dev/null 2>&1 &

ui_print "- 🐾尝试清除缓存，修复异常"
cache_path=/data/dalvik-cache/arm
[ -d $cache_path"64" ] && cache_path=$cache_path"64"
for fileName in $system_ext_cache; do
  rm -f $cache_path/system_ext@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done
for fileName in $system_cache; do
  rm -f $cache_path/system@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done

ui_print "- 👾设置权限"
set_perm_recursive $MODPATH 0 0 0755 0644
}
Information
Ifff
Install
