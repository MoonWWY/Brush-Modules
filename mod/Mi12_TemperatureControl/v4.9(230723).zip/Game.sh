#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl

clouds="com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver"

clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose"

Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

function Disable_cloud(){
for i in ${clouds}; do
  pm disable ${i}
done
for i in ${clears}; do
  pm clear ${i}
done
pm suspend com.miui.analytics
pm hide com.miui.analytics
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity
for i in ${Cloud_address}; do
  iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -A INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}

/system/bin/sh ${ModuleAdd}/Killcloud.sh
Disable_cloud