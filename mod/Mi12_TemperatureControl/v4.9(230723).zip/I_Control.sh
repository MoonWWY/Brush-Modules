#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
Mod_information=/data/adb/modules/Mi12_TemperatureControl/module.prop
KillLog_time=`date +"%H:%M:%S"`

function Update_information1(){
sed -i "/^description=/c description=当前模式：[ ✈️极速游戏 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充，淦掉云控，游戏全性能。配置目录：/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf" "$Mod_information"
}

function Update_information2(){
sed -i "/^description=/c description=当前模式：[ 🛰️淦掉云控 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充，淦掉云控。配置目录：/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf" "$Mod_information"
}

function Update_information3(){
sed -i "/^description=/c description=当前模式：[ 💀淦掉温控 🔪| $KillLog_time | ] 目前功能：淦掉温控，满血快充。配置目录：/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf" "$Mod_information"
}

if [ ! -f "$Config_add/配置文件.conf" ];then
  cp -rf ${ModuleAdd}/配置文件.conf ${Config_add}/
else
  cp -rf ${Config_add}/配置文件.conf ${ModuleAdd}/
fi

/system/bin/sh $ModuleAdd/Initialization.sh

if [ -f "$ModuleAdd/配置文件.conf" ]; then
  Current_mode=`cat ${ModuleAdd}/配置文件.conf | grep "Current_mode" | cut -d"=" -f2`
  if [ "$Current_mode" = "killcloud" ]; then
    /system/bin/sh ${ModuleAdd}/Killcloud.sh
    Update_information2
  elif [ "$Current_mode" = "game" ]; then
    /system/bin/sh ${ModuleAdd}/Killcloud.sh
    /system/bin/sh ${ModuleAdd}/Game.sh
    Update_information1
  else
    /system/bin/sh ${ModuleAdd}/Initialization.sh
    Update_information3
  fi
else
  /system/bin/sh ${ModuleAdd}/Initialization.sh
  Update_information3
fi