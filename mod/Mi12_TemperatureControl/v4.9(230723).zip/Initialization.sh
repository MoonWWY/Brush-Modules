#!/system/bin/sh
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl

chattr -R -i /data/vendor/thermal/config
chmod -R 777 /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
bak_file=`ls  ${Config_add}/First_install_bak/cloud_thermals/ | wc -l`
if [ "$bak_file" -gt "0" ]; then
  cp -rf ${Config_add}/First_install_bak/cloud_thermals/* /data/vendor/thermal/config/
fi

clouds="com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver"

Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

function Enable_the_cloud(){
for i in ${clouds}; do
  pm enable ${i}
done
pm unsuspend com.miui.analytics
pm unhide com.miui.analytics
pm disable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
for i in ${Cloud_address}; do
  iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}
Enable_the_cloud
