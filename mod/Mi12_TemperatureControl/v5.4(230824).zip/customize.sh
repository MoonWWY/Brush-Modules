#!/system/bin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
DUBUG_FLAG=true
SKIPUNZIP=0
ASH_STANDALONE=0

function Information() {
name="`grep_prop name $TMPDIR/module.prop`"
version="`grep_prop version $TMPDIR/module.prop`"
author="`grep_prop author $TMPDIR/module.prop`"
description="`grep_prop description $TMPDIR/module.prop`"
ui_print "********************"
ui_print "- 模块信息"
ui_print "- 名称: $name"
ui_print "- 版本: $version"
ui_print "- 作者：$author"
ui_print "- $description"
ui_print "********************"
}

function Ifff() {
ui_print "————————————————————————————————————"
ui_print "- 特此声明："
ui_print "- 本模块已适配自动淦云控功能"
ui_print "- 你可以选择“模块运行永久淦掉云控文件”"
ui_print "- 也可以选择“设定场景下自动淦掉”"
ui_print "- 默认auto。如需配置，请在："
ui_print "/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf"
ui_print "- 中修改，感谢支持。"
ui_print "————————————————————————————————————"
ui_print "- 非常抱歉！！！由于版本差异，为避免异常："
ui_print "- 此后版本无论是第一次安装还是覆盖安装，都需要重新配置“配置文件.conf”"
ui_print "————————————————————————————————————"
sleep 2
ui_print "- 准备安装模块~"
}

function Install() {
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
sleep 1
ui_print "- Install~"
ui_print "- 🚀清除旧版本配置文件"
if [ -d "${Config_add}/" ];then
  rm -rf ${Config_add}/*
else
  mkdir -p ${Config_add}/
fi
script_name="/system/bin/sh /data/adb/modules/Mi12_TemperatureControl/Dynamic_cloud_control.sh"
lastID=$(pgrep -f "$script_name")
if [ "$lastID" != "" ]; then
  kill -KILL $lastID
fi

ui_print "- 💞初始化模块文件"
cp -rf $MODPATH/免重启更新配置.sh ${Config_add}/
cp -rf $MODPATH/配置文件.conf ${Config_add}/
function install_magisk_busybox() {
mkdir -p /data/adb/busybox
	/data/adb/magisk/busybox --install -s /data/adb/busybox
	chmod -R 0755 /data/adb/busybox 
export PATH=/data/adb/busybox:$PATH
}
install_magisk_busybox

product=$MODPATH/system/product
if [ ! -d "$product" ]; then
  mkdir -p ${product}
  cp -p -a -R /system/product/pangu/system/* ${product}
fi
sed -i "/^description=/c description=当前模式：[ NULL | -等待重启- ] ，Mi·淦掉温控：不跳电淦温控，淦掉云控，满血快充(会阶梯式充电，也会受机身48℃温度墙影响)，游戏不掉帧，兼容A12/A13，MIUI13/MIUI14。" $MODPATH/module.prop

ui_print "- 🐾尝试清除缓存，修复异常"
cache_path=/data/dalvik-cache/arm
[ -d $cache_path"64" ] && cache_path=$cache_path"64"
for fileName in $system_ext_cache; do
  rm -f $cache_path/system_ext@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done
for fileName in $system_cache; do
  rm -f $cache_path/system@*@"$fileName"*
  rm -f /data/system/package_cache/*/"$fileName"*
done

ui_print "- 👾设置权限"
set_perm_recursive $MODPATH 0 0 0755 0644
}
Information
Ifff
Install
