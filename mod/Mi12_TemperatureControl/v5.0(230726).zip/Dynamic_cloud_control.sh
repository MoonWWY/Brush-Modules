#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
Mod_information=/data/adb/modules/Mi12_TemperatureControl/module.prop

clouds="com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose
com.miui.analytics
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseJobScheduleService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.predownload.PreDownloadJobScheduler
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver"

clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose"

Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

function Disable_cloud(){
for i in ${clouds}; do
  pm disable ${i}
done
for i in ${clears}; do
  pm clear ${i}
done
pm suspend com.miui.analytics
pm hide com.miui.analytics
pm enable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
pm enable com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity
for i in ${Cloud_address}; do
  iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -A INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}

function Enable_the_cloud(){
for i in ${clouds}; do
  pm enable ${i}
done
pm unsuspend com.miui.analytics
pm unhide com.miui.analytics
pm disable com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
for i in ${Cloud_address}; do
  iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}

function Killcloud(){
chattr -R -i /data/vendor/thermal/config
cp -rf $ModuleAdd/clouds/* /data/vendor/thermal/config/
chmod -R 644 /data/vendor/thermal/config/
chattr -R +i /data/vendor/thermal/config
}

function Recoverycloud(){
chattr -R -i /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
bak_file=`ls  ${Config_add}/First_install_bak/cloud_thermals/ | wc -l`
if [ "$bak_file" -gt "0" ]; then
  cp -rf ${Config_add}/First_install_bak/cloud_thermals/* /data/vendor/thermal/config/
fi
}

function Update_information(){
KillLog_time=`date +"%H:%M:%S"`
sed -i "/^description=/c description=当前状态：【 🛸RUNNING:[ ${playing} ] 🌡️[ ${Degree}℃ ] 🔪[ $KillLog_time ] 】 模块功能：淦掉温控，满血快充，淦掉云控，游戏全性能。配置目录：/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf" "$Mod_information"
}

if [ ! -f "$Config_add/配置文件.conf" ];then
  cp -rf ${ModuleAdd}/配置文件.conf ${Config_add}/
else
  cp -rf ${Config_add}/配置文件.conf ${ModuleAdd}/
fi

games=`cat ${ModuleAdd}/配置文件.conf | grep -v "^#" | grep -v "^$"`
Current_mode=`cat ${ModuleAdd}/配置文件.conf | grep "Current_mode" | cut -d"=" -f2`

if [ -f "$ModuleAdd/配置文件.conf" ]; then
while true; do
  battery=$(find /sys/devices/ -iname "battery" -type d)
  Temp=$(cat $battery/temp)
  if [ "$Temp" -lt "480" ]; then
    for game in ${games}; do
      if ps -A | grep -E "$game">/dev/null;then
        playing=${game}
        State_mod="run"
        if [ "$State_game" = "null" ]; then
          State_game="run"
          State_mod="run"
          if [ "$Current_mode" = "auto" ]; then
            Killcloud
          fi
          Disable_cloud
        fi
        break
      else
      playing="null"
      fi
    done    
    if [ "$playing" = "null" ]; then
      if [ "$State_mod" = "run" ]; then
        if [ "$Current_mode" = "auto" ]; then
          Recoverycloud
        fi
        Enable_the_cloud
        State_game="null"
        State_mod="stop"
      else
        State_game="null"
      fi
    fi
  else
    playing="Overheating"
  fi
  if [ "$playing" = "Overheating" ]; then
    if [ "$State_mod" = "run" ]; then
      Recoverycloud
      Enable_the_cloud
      State_game="null"
      State_mod="stop"
    fi
  fi
  Degree=$((Temp/10)).$((Temp%10))
  Update_information
  sleep 10
done
fi