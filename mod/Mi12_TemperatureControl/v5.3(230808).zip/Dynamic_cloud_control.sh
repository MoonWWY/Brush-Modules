#!/system/bin/sh
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
Config_add=/storage/emulated/0/Android/Mi12_TemperatureControl
Mod_information=/data/adb/modules/Mi12_TemperatureControl/module.prop

clouds="com.miui.powerkeeper/com.miui.powerkeeper.ui.ThermalConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.thermalconfig.ThermalConfigReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqMinService
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.processmem.ProcessMemService
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.PowerToolsConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.gpumem.GpuMemService
com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.thermal.BoardTempService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.TimeInStateService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqCurService
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.TopCmdService
com.miui.powerkeeper/com.miui.powerkeeper.PowerKeeperReceiver
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose/com.xiaomi.joyose.securitycenter.GPUTunerService
com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseBroadCastReceiver
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver
com.miui.daemon/com.miui.daemon.performance.MiuiPerfService
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
com.miui.daemon/com.miui.daemon.performance.server.ExecutorService
com.miui.daemon/com.miui.daemon.mqsas.jobs.HeartBeatUploadService"

clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose
com.miui.daemon"

Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"

function Disable_cloud(){
for i in ${clouds}; do
  pm disable ${i}
done
for i in ${clears}; do
  pm clear ${i}
done
pm suspend com.miui.analytics
pm hide com.miui.analytics
for i in ${Cloud_address}; do
  iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -A INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}

function Enable_the_cloud(){
for i in ${clouds}; do
  pm enable ${i}
done
pm unsuspend com.miui.analytics
pm unhide com.miui.analytics
for i in ${Cloud_address}; do
  iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
}

function Killcloud(){
rm -rf /cache/miui-thermal/*
chattr -R -i /data/vendor/thermal/config
cp -rf $ModuleAdd/clouds/* /data/vendor/thermal/config/
chmod -R 644 /data/vendor/thermal/config/
chattr -R +i /data/vendor/thermal/config
}

function Recoverycloud(){
chattr -R -i /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
cmd activity broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
}

function Update_information(){
KillLog_time=`date +"%H:%M:%S"`
sed -i "/^description=/c description=当前状态：【 🛸RUNNING:[ ${playing} ] 🌡️[ ${Degree}℃ ] 🔪[ $KillLog_time ] 】 模块功能：淦掉温控，满血快充，淦掉云控，游戏全性能。配置目录：/storage/emulated/0/Android/Mi12_TemperatureControl/配置文件.conf" "$Mod_information"
}

function Dynamic_control(){
while true; do
  if [ ! -f "$Config_add/配置文件.conf" ];then
    cp -rf ${ModuleAdd}/配置文件.conf ${Config_add}/
  else
    cp -rf ${Config_add}/配置文件.conf ${ModuleAdd}/
  fi
  games=`cat ${ModuleAdd}/配置文件.conf | grep -v "^#" | grep -v "^$"`
  battery=$(find /sys/devices/ -iname "battery" -type d)
  Temp=$(cat $battery/temp)
  if [ "$Temp" -lt "520" ]; then
    for game in ${games}; do
      if ps -A | grep -E "$game">/dev/null;then
        playing=${game}
        State_mod="run"
        if [ "$State_game" = "null" ]; then
          State_game="run"
          State_mod="run"
          Killcloud
          Disable_cloud
        fi
        break
      else
      playing="null"
      fi
    done    
    if [ "$playing" = "null" ]; then
      if [ "$State_mod" = "run" ]; then
        Recoverycloud
        Enable_the_cloud
        State_game="null"
        State_mod="stop"
      else
        State_game="null"
      fi
    fi
  else
    playing="Overheating"
  fi
  if [ "$playing" = "Overheating" ]; then
    if [ "$State_mod" = "run" ]; then
      Recoverycloud
      Enable_the_cloud
      State_game="null"
      State_mod="stop"
    fi
  fi
  Degree=$((Temp/10)).$((Temp%10))
  Update_information
  sleep 10
done
}

if [ -f "$ModuleAdd/配置文件.conf" ]; then
  if [ ! -f "$Config_add/配置文件.conf" ];then
    cp -rf ${ModuleAdd}/配置文件.conf ${Config_add}/
  else
    cp -rf ${Config_add}/配置文件.conf ${ModuleAdd}/
  fi
  Current_mode=`cat ${ModuleAdd}/配置文件.conf | grep "Current_mode" | cut -d"=" -f2`
  if [ "$Current_mode" = "killcloud" ]; then
    playing="Mode=Killcloud"
    Degree="null"
    Killcloud
    Update_information
  elif [ "$Current_mode" = "auto" ]; then
    Dynamic_control
  else
    playing="Mode=default"
    Degree="null"
    Update_information
  fi
fi