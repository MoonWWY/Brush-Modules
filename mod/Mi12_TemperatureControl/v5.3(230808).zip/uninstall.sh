#!/system/bin/sh
function Uninstall_modules(){
chattr -R -i /data/vendor/thermal/config
chmod -R 777 /data/vendor/thermal/config
rm -rf /data/vendor/thermal/config/*
chattr -R -i /data/system/mcd
mkdir /data/system/mcd
chmod 755 /data/system/mcd
clouds="com.miui.powerkeeper/com.xiaomi.mipush.sdk.PushMessageHandler
com.miui.powerkeeper/com.xiaomi.push.service.receivers.PingReceiver
com.miui.powerkeeper/com.xiaomi.mipush.sdk.MessageHandleService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.interrupt.InterruptsActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.ThermalConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.current.CurrentService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.thermal.ThermalDetailActivity
com.miui.powerkeeper/com.miui.powerkeeper.thermalconfig.ThermalConfigReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.PowerToolsActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqMinService
com.miui.powerkeeper/com.miui.powerkeeper.ui.ScenarioPowerSavingActivity
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.processmem.ProcessMemService
com.miui.powerkeeper/com.miui.powerkeeper.powerchecker.PowerCheckerService
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.FrameRateSecretCodeReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.batterylife.BatteryStatusActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.CommonService
com.miui.powerkeeper/com.miui.powerkeeper.ui.HiddenAppsConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.top.TopCmdService
com.miui.powerkeeper/com.miui.powerkeeper.ui.HiddenAppsContainerManagementActivity
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.PowerToolsConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.PowerKeeperBackgroundService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.frame.FrameRate2Service
com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.gpumem.GpuMemService
com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.floating.MiFloatingService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.thermal.BoardTempService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.interrupt.InterruptsService
com.miui.powerkeeper/com.xiaomi.push.service.receivers.NetworkStatusReceiver
com.miui.powerkeeper/com.miui.powerkeeper.WakelockManagerService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.TimeInStateService
com.miui.powerkeeper/com.miui.powerkeeper.provider.PowerKeeperConfigureProvider
com.miui.powerkeeper/com.miui.powerkeeper.resource.bigdata.resourcelight.GreenifyService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqCurService
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.TopCmdService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.batterydry.DryService
com.miui.powerkeeper/com.miui.powerkeeper.PowerKeeperReceiver
com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.FeedbackControlService
com.miui.securityadd/com.miui.gamebooster.pannel.PannelControlActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose/com.xiaomi.joyose.securitycenter.GPUTunerService
com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseBroadCastReceiver
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver
com.miui.daemon/com.miui.daemon.performance.MiuiPerfService
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
com.miui.daemon/com.miui.daemon.performance.server.ExecutorService
com.miui.daemon/com.miui.daemon.mqsas.jobs.HeartBeatUploadService"
clears="com.miui.powerkeeper
com.miui.analytics
com.xiaomi.joyose
com.miui.daemon"
Cloud_address="jupiter.rus.sys.miui.com
jupiter.india.sys.miui.com
jupiter.intl.sys.miui.com
jupiter.sys.miui.com
preview-jupiter.sys.miui.com
preview-jupiter.india.sys.miui.com
preview-jupiter.intl.sys.miui.com
preview-jupiter.rus.sys.miui.com
rom.pt.miui.srv
cc.sys.intl.xiaomi.com
ccc.sys.intl.xiaomi.com
cc.sys.miui.com
ccc.sys.miui.com"
for i in ${clouds}; do
  pm enable ${i}
done
for i in ${clears}; do
  pm clear ${i}
  pm enable ${i}
done
for i in ${Cloud_address}; do
  iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
  iptables -D INPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done
pm unsuspend com.miui.analytics
pm unhide com.miui.analytics
rm -rf /data/user/0/com.miui.powerkeeper/*
rm -rf /data/system/package_cache/*
rm -rf /data/app/com.miui.powerkeeper/*
chmod -R 644 /data/vendor/thermal/config
am start -n com.xiaomi.joyose/.sysbase.FakeCellSettingsActivity
sleep 3
cmd activity broadcast --user 0 -a update_profile com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver >/dev/null 2>&1 &
am force-stop com.xiaomi.joyose
rm -rf /data/adb/modules/Mi12_TemperatureControl/
rm -rf /storage/emulated/0/Android/Mi12_TemperatureControl/
}
Uninstall_modules
alias sh='/system/bin/sh'
killall sh