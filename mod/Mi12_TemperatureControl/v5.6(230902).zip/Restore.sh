#!/system/bin/sh
clouds="com.miui.powerkeeper
com.miui.powerkeeper/com.xiaomi.mipush.sdk.PushMessageHandler
com.miui.powerkeeper/com.xiaomi.push.service.receivers.PingReceiver
com.miui.powerkeeper/com.xiaomi.mipush.sdk.MessageHandleService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.interrupt.InterruptsActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.ThermalConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.current.CurrentService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.thermal.ThermalDetailActivity
com.miui.powerkeeper/com.miui.powerkeeper.thermalconfig.ThermalConfigReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.PowerToolsActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqMinService
com.miui.powerkeeper/com.miui.powerkeeper.ui.ScenarioPowerSavingActivity
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.processmem.ProcessMemService
com.miui.powerkeeper/com.miui.powerkeeper.powerchecker.PowerCheckerService
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.FrameRateSecretCodeReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.batterylife.BatteryStatusActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.CommonService
com.miui.powerkeeper/com.miui.powerkeeper.ui.HiddenAppsConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.top.TopCmdService
com.miui.powerkeeper/com.miui.powerkeeper.ui.HiddenAppsContainerManagementActivity
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.PowerToolsConfigActivity
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.powerkeeper/com.miui.powerkeeper.PowerKeeperBackgroundService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.frame.FrameRate2Service
com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.abnormallog.ThermalLogService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.gpumem.GpuMemService
com.miui.powerkeeper/com.miui.powerkeeper.logsystem.LogSystemService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.floating.MiFloatingService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.thermal.BoardTempService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.interrupt.InterruptsService
com.miui.powerkeeper/com.xiaomi.push.service.receivers.NetworkStatusReceiver
com.miui.powerkeeper/com.miui.powerkeeper.WakelockManagerService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.TimeInStateService
com.miui.powerkeeper/com.miui.powerkeeper.provider.PowerKeeperConfigureProvider
com.miui.powerkeeper/com.miui.powerkeeper.resource.bigdata.resourcelight.GreenifyService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.cpu.CpuFreqCurService
com.miui.powerkeeper/com.miui.powerkeeper.ui.framerate.TopCmdService
com.miui.powerkeeper/com.miui.powerkeeper.ui.powertools.module.batterydry.DryService
com.miui.powerkeeper/com.miui.powerkeeper.PowerKeeperReceiver
com.miui.powerkeeper/com.miui.powerkeeper.feedbackcontrol.FeedbackControlService
com.miui.securityadd/com.miui.gamebooster.pannel.PannelControlActivity
com.miui.powerkeeper/com.miui.powerkeeper.statemachine.PowerStateMachineService
com.xiaomi.joyose/com.xiaomi.joyose.securitycenter.GPUTunerService
com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
com.xiaomi.joyose/com.xiaomi.joyose.cloud.LocalCtrlActivity
com.xiaomi.joyose/com.xiaomi.joyose.JoyoseBroadCastReceiver
com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
com.xiaomi.joyose/com.xiaomi.joyose.smartop.gamebooster.receiver.BoostRequestReceiver
com.miui.daemon/com.miui.daemon.performance.MiuiPerfService
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
com.miui.daemon/com.miui.daemon.performance.mispeed.CloudServerReceiver
com.miui.daemon/com.miui.daemon.performance.server.ExecutorService
com.miui.daemon/com.miui.daemon.mqsas.jobs.HeartBeatUploadService"

for i in ${clouds}; do
  pm enable ${i}
done

function Initialization_file(){
ModuleAdd=/data/adb/modules/Mi12_TemperatureControl
thermals=`ls /system/bin/*thermal* /system/etc/init/*thermal* /system/etc/perf/*thermal* /system/vendor/bin/*thermal* /system/vendor/etc/*thermal* /system/vendor/etc/powerhint* /system/vendor/etc/init/*_thermal* /system/vendor/etc/perf/*thermal* /system/vendor/lib/hw/thermal* /system/vendor/lib64/hw/thermal* 2>/dev/null | grep -v mi_thermald | grep -v thermal-engine.conf | grep -v thermal-normal.conf | grep -v thermal-map.conf | grep -v thermal-engine | grep -v thermalserviced | grep -v "*.so"`

for thermal in $thermals; do
  [[ ! -d $ModuleAdd/thermals/${thermal%/*} ]] && mkdir -p $ModuleAdd/thermals/${thermal%/*}
  touch $ModuleAdd/thermals/$thermal
done

systems="/system/bin /system/etc/init /system/etc/perf /system/vendor/bin /system/vendor/etc /system/vendor/etc /system/vendor/etc/init /system/vendor/etc/perf /system/vendor/lib/hw /system/vendor/lib64/hw"
for system in $systems; do
  if [ -d "$system" ];then
    mkdir -p $ModuleAdd/$system
  fi
done

cp -rf $ModuleAdd/thermals/system/ $ModuleAdd
rm -rf $ModuleAdd/thermals/
}
Initialization_file

chattr -R -i /data/system/mcd
mkdir /data/system/mcd
chmod 755 /data/system/mcd