#!/system/bin/sh
Updir=/data/adb/modules/Mi12_TemperatureControl/
curl -o $Updir/updatefile.zip "https://share.yyycontrol.top/d/updatemod/Mi12_TemperatureControl/update/updatefile.zip"
unzip -qo $Updir/updatefile.zip -d $Updir
chmod a+x $Updir/*.sh
rm -rf $Updir/updatefile.zip