#!/system/bin/sh
unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2